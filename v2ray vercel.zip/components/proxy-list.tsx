"use client"

import type React from "react"

import { memo, useState, useCallback, useEffect, useRef } from "react"
import { SearchInput } from "@/components/search-input"
import { Pagination } from "@/components/pagination"
import { getEmojiFlag } from "@/lib/utils"
import type { Proxy } from "@/types/proxy"

interface ProxyListProps {
  loading: boolean
  error: string | null
  searchQuery: string
  onSearch: (query: string) => void
  currentProxies: Proxy[]
  activeTabIndex: number
  onTabSelect: (index: number) => void
  indexOfFirstProxy: number
  currentPage: number
  totalPages: number
  paginate: (pageNumber: number) => void
  proxiesPerPage: number
  onProxiesPerPageChange: (value: number) => void
  totalProxies: number
  indexOfLastProxy: number
  isMobileView: boolean
}

interface ProxyStatusData {
  isActive: boolean
  latency: string
  flag?: string
  org?: string
  error?: string
  lastChecked?: number
}

export const ProxyList = memo(function ProxyList({
  loading,
  error,
  searchQuery,
  onSearch,
  currentProxies,
  activeTabIndex,
  onTabSelect,
  indexOfFirstProxy,
  currentPage,
  totalPages,
  paginate,
  proxiesPerPage,
  onProxiesPerPageChange,
  totalProxies,
  indexOfLastProxy,
  isMobileView,
}: ProxyListProps) {
  // Add state to track active status of proxies
  const [proxyStatus, setProxyStatus] = useState<Record<string, ProxyStatusData>>({})
  const [checkingStatus, setCheckingStatus] = useState<Record<string, boolean>>({})
  const [autoCheckEnabled, setAutoCheckEnabled] = useState(false) // Disabled by default now
  const checkQueue = useRef<string[]>([])
  const isProcessingQueue = useRef(false)

  // Function to check a single proxy status
  const checkSingleProxyStatus = useCallback(async (proxy: Proxy): Promise<ProxyStatusData> => {
    const proxyKey = `${proxy.proxyIP}:${proxy.proxyPort}`

    try {
      // Use our server-side API route
      const response = await fetch(
        `/api/check-proxy?ip=${encodeURIComponent(proxy.proxyIP)}&port=${encodeURIComponent(proxy.proxyPort)}`,
      )

      if (!response.ok) {
        throw new Error(`API responded with status: ${response.status}`)
      }

      const data = await response.json()
      console.log("Proxy status response:", data)

      return {
        isActive: data.proxyip === true,
        latency: data.latency || "Unknown",
        flag: data.flag || getEmojiFlag(proxy.country),
        org: data.org || proxy.org,
        lastChecked: Date.now(),
      }
    } catch (error) {
      console.error("Error checking proxy status:", error)
      return {
        isActive: false,
        latency: "Error",
        error: error instanceof Error ? error.message : "Unknown error",
        flag: getEmojiFlag(proxy.country),
        org: proxy.org,
        lastChecked: Date.now(),
      }
    }
  }, [])

  // Function to process the queue of proxies to check
  const processQueue = useCallback(async () => {
    if (isProcessingQueue.current || checkQueue.current.length === 0) return

    isProcessingQueue.current = true

    try {
      // Process up to 3 proxies at a time
      const batch = checkQueue.current.splice(0, 3)

      // Mark these proxies as being checked
      setCheckingStatus((prev) => {
        const newState = { ...prev }
        batch.forEach((key) => {
          newState[key] = true
        })
        return newState
      })

      // Find the proxy objects for these keys
      const proxiesToCheck = batch
        .map((key) => {
          const [ip, port] = key.split(":")
          return currentProxies.find((p) => p.proxyIP === ip && p.proxyPort === port)
        })
        .filter(Boolean) as Proxy[]

      // Check them in parallel
      const results = await Promise.all(proxiesToCheck.map((proxy) => checkSingleProxyStatus(proxy)))

      // Update the status for each proxy
      setProxyStatus((prev) => {
        const newState = { ...prev }
        proxiesToCheck.forEach((proxy, index) => {
          const key = `${proxy.proxyIP}:${proxy.proxyPort}`
          newState[key] = results[index]
        })
        return newState
      })

      // Mark these proxies as no longer being checked
      setCheckingStatus((prev) => {
        const newState = { ...prev }
        batch.forEach((key) => {
          newState[key] = false
        })
        return newState
      })

      // If there are more proxies in the queue, continue processing after a short delay
      if (checkQueue.current.length > 0) {
        setTimeout(() => {
          isProcessingQueue.current = false
          processQueue()
        }, 500)
      } else {
        isProcessingQueue.current = false
      }
    } catch (error) {
      console.error("Error processing queue:", error)
      isProcessingQueue.current = false
    }
  }, [currentProxies, checkSingleProxyStatus])

  // Function to manually check a proxy status
  const checkProxyStatus = useCallback(
    (proxy: Proxy, event?: React.MouseEvent) => {
      if (event) {
        event.stopPropagation() // Prevent triggering the proxy selection
      }

      const proxyKey = `${proxy.proxyIP}:${proxy.proxyPort}`

      if (checkingStatus[proxyKey]) return // Prevent duplicate requests

      // Add to queue if not already in it
      if (!checkQueue.current.includes(proxyKey)) {
        checkQueue.current.push(proxyKey)
        processQueue()
      }
    },
    [checkingStatus, processQueue],
  )

  // Auto-check visible proxies when they change - only if autoCheckEnabled is true
  useEffect(() => {
    if (!autoCheckEnabled || loading || error || currentProxies.length === 0) return

    // Only check proxies that are currently displayed on the screen
    // Add visible proxies to the check queue if they haven't been checked recently
    const now = Date.now()
    const CACHE_TIME = 5 * 60 * 1000 // 5 minutes

    currentProxies.forEach((proxy) => {
      const proxyKey = `${proxy.proxyIP}:${proxy.proxyPort}`
      const status = proxyStatus[proxyKey]

      // Only check if:
      // 1. Not already being checked
      // 2. Not already in the queue
      // 3. Either never checked before or checked more than 5 minutes ago
      if (
        !checkingStatus[proxyKey] &&
        !checkQueue.current.includes(proxyKey) &&
        (!status || !status.lastChecked || now - status.lastChecked > CACHE_TIME)
      ) {
        checkQueue.current.push(proxyKey)
      }
    })

    // Start processing the queue if it's not already being processed
    if (checkQueue.current.length > 0 && !isProcessingQueue.current) {
      processQueue()
    }
  }, [currentProxies, autoCheckEnabled, loading, error, checkingStatus, proxyStatus, processQueue])

  // Toggle auto-check function
  const toggleAutoCheck = useCallback(() => {
    setAutoCheckEnabled((prev) => !prev)
  }, [])

  return (
    <div className="bg-tech-card p-3 sm:p-4 flex flex-col gap-3 sm:gap-4 animate-fadeIn">
      <div className="flex flex-col sm:flex-row justify-between items-center gap-2 animate-fadeInDown">
        <SearchInput
          value={searchQuery}
          onChange={onSearch}
          placeholder="Search by Country/Org"
          className="w-full sm:flex-1"
        />

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <select
            value={proxiesPerPage}
            onChange={(e) => onProxiesPerPageChange(Number(e.target.value))}
            className="tech-select w-full sm:w-auto mt-2 sm:mt-0 text-sm"
            aria-label="Items per page"
          >
            <option value={5}>5 per page</option>
            <option value={10}>10 per page</option>
            <option value={20}>20 per page</option>
            <option value={50}>50 per page</option>
          </select>

          <button
            onClick={toggleAutoCheck}
            className={`mt-2 sm:mt-0 text-xs px-2 py-1 rounded transition-all duration-300 ${
              autoCheckEnabled ? "bg-tech-accent text-white animate-pulse-glow" : "bg-tech-bg text-tech-muted"
            }`}
            title={autoCheckEnabled ? "Disable auto-check" : "Enable auto-check"}
          >
            Auto
          </button>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-40 animate-scaleIn">
          <div className="w-16 h-16 border-4 border-tech-accent border-t-transparent rounded-full animate-spin"></div>
        </div>
      ) : error ? (
        <div className="text-red-500 p-4 bg-tech-bg rounded-lg animate-fadeInUp">
          <p className="font-bold mb-2">Error loading proxies:</p>
          <p>{error}</p>
        </div>
      ) : (
        <>
          <div className="space-y-2 max-h-[60vh] overflow-y-auto pr-1">
            {currentProxies.map((proxy, index) => {
              const proxyKey = `${proxy.proxyIP}:${proxy.proxyPort}`
              const isChecking = checkingStatus[proxyKey]
              const status = proxyStatus[proxyKey]
              const statusChecked = proxyKey in proxyStatus

              return (
                <button
                  key={proxyKey}
                  onClick={() => onTabSelect(indexOfFirstProxy + index)}
                  className={`w-full text-left py-1.5 px-2 sm:py-2 sm:px-3 flex items-center gap-2 sm:gap-3 transition-all duration-300 stagger-item animate-fadeInUp h-[60px] sm:h-[68px] ${
                    activeTabIndex === indexOfFirstProxy + index ? "tech-tab active animate-glow" : "tech-tab"
                  }`}
                  data-country={proxy.country.toLowerCase()}
                >
                  <span className="text-lg sm:text-xl animate-pulse-soft">{getEmojiFlag(proxy.country)}</span>
                  <div className="flex-1 min-w-0">
                    <div className="truncate font-medium text-xs sm:text-sm">{proxy.org}</div>
                    <div className="text-xs text-tech-muted truncate">
                      {proxy.proxyIP}:{proxy.proxyPort}
                    </div>
                  </div>
                  <div className="flex flex-col items-end justify-center status-transition h-full min-h-[36px]">
                    {isChecking ? (
                      <div className="text-xs flex items-center text-tech-muted animate-fadeIn">
                        <div className="smooth-spinner mr-2"></div>
                        <span className="animate-pulse-glow">Checking...</span>
                      </div>
                    ) : statusChecked ? (
                      <div className="text-right animate-fadeIn">
                        <span
                          className={`text-xs font-medium ${
                            status.isActive ? "text-tech-success animate-pulse-glow" : "text-red-500"
                          }`}
                        >
                          {status.isActive ? "ACTIVE" : "NON-ACTIVE"}
                        </span>
                        {status.latency !== "Error" && status.latency !== "Unknown" && status.isActive && (
                          <span className="block text-xs text-tech-muted animate-fadeInDown">{status.latency}</span>
                        )}
                        <button
                          onClick={(e) => checkProxyStatus(proxy, e)}
                          className="text-xs text-tech-muted hover:text-tech-accent mt-1 transition-all duration-300 hover:scale-105"
                        >
                          Check Again
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={(e) => checkProxyStatus(proxy, e)}
                        className="text-xs text-tech-muted hover:text-tech-accent transition-all duration-300 hover:scale-105"
                      >
                        Check Status
                      </button>
                    )}
                  </div>
                </button>
              )
            })}
          </div>

          {totalProxies > 0 ? (
            <>
              <Pagination currentPage={currentPage} totalPages={totalPages} paginate={paginate} />

              <div className="text-center text-sm mt-2 text-tech-muted animate-fadeInUp">
                Showing {indexOfFirstProxy + 1}-{Math.min(indexOfLastProxy, totalProxies)} of {totalProxies} proxies
              </div>
            </>
          ) : (
            <div className="text-center p-4 text-tech-muted animate-fadeInUp">
              No proxies found matching your search.
            </div>
          )}
        </>
      )}
    </div>
  )
})

