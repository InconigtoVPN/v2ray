"use client"

import type React from "react"

import { memo, useCallback, useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { CopyButton } from "@/components/copy-button"
import { getEmojiFlag } from "@/lib/utils"
import type { Proxy } from "@/types/proxy"
import { generateConfigs } from "@/lib/config-generator"
import { Label } from "@/components/ui/label"

// Update the ProxyCardProps interface to include the new serverType and sslServers props
interface ProxyCardProps {
  proxy: Proxy
  hostName: string
  nameWEB: string
  pathinfo: string
  useWildcard?: boolean
  wildcardSubdomain?: string
  wildcardFullHost?: string
  availableHostNames: string[]
  availableBugServers: string[]
  availableSslServers?: string[]
  serverType?: string
  onSettingsChange: (settings: {
    hostName: string
    useWildcard: boolean
    wildcardSubdomain: string
    wildcardFullHost: string
    serverType?: string
  }) => void
}

// Update the component to destructure the new props with default values
export const ProxyCard = memo(function ProxyCard({
  proxy,
  hostName,
  nameWEB,
  pathinfo,
  useWildcard = false,
  wildcardSubdomain = "",
  wildcardFullHost = "",
  availableHostNames = [],
  availableBugServers = [],
  availableSslServers = [],
  serverType = "WS",
  onSettingsChange,
}: ProxyCardProps) {
  const { proxyIP, proxyPort, country, org } = proxy
  const [localHostName, setLocalHostName] = useState(hostName)
  const [localUseWildcard, setLocalUseWildcard] = useState(useWildcard)
  const [localWildcardSubdomain, setLocalWildcardSubdomain] = useState(wildcardSubdomain)
  const [localWildcardFullHost, setLocalWildcardFullHost] = useState(wildcardFullHost)
  const [localServerType, setLocalServerType] = useState(serverType)
  const [settingsSaved, setSettingsSaved] = useState(false)

  // Add these new state variables after the existing useState declarations
  const [proxyStatus, setProxyStatus] = useState<{ isActive: boolean; latency: string } | null>(null)
  const [checkingStatus, setCheckingStatus] = useState(false)

  // Update local state when props change
  useEffect(() => {
    setLocalHostName(hostName)
    setLocalUseWildcard(useWildcard)
    setLocalWildcardSubdomain(wildcardSubdomain)
    setLocalWildcardFullHost(wildcardFullHost)
    setLocalServerType(serverType)
  }, [hostName, useWildcard, wildcardSubdomain, wildcardFullHost, serverType])

  // Modify the useEffect that watches for proxy changes to automatically check the status
  // Replace the existing useEffect that resets the status with this one:

  useEffect(() => {
    // Reset proxy status when the proxy changes and automatically check the new proxy
    setProxyStatus(null)
    setCheckingStatus(true)

    // Automatically check the status of the new proxy
    const checkStatus = async () => {
      try {
        const response = await fetch(
          `/api/check-proxy?ip=${encodeURIComponent(proxy.proxyIP)}&port=${encodeURIComponent(proxy.proxyPort)}`,
        )

        if (!response.ok) {
          throw new Error(`API responded with status: ${response.status}`)
        }

        const data = await response.json()

        setProxyStatus({
          isActive: data.proxyip === true,
          latency: data.latency || "Unknown",
        })
      } catch (error) {
        console.error("Error checking proxy status:", error)
        setProxyStatus({
          isActive: false,
          latency: "Error",
        })
      } finally {
        setCheckingStatus(false)
      }
    }

    checkStatus()
  }, [proxy.proxyIP, proxy.proxyPort]) // Depend on the proxy IP and port to detect changes

  // Handle hostname change
  const handleHostNameChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newHostName = e.target.value
    setLocalHostName(newHostName)

    // Update wildcard full host if using wildcard
    const updatedWildcardFullHost =
      localUseWildcard && localWildcardSubdomain ? `${localWildcardSubdomain}.${newHostName}` : localWildcardFullHost

    if (localUseWildcard && localWildcardSubdomain) {
      setLocalWildcardFullHost(updatedWildcardFullHost)
    }

    // Automatically save settings
    onSettingsChange({
      hostName: newHostName,
      useWildcard: localUseWildcard,
      wildcardSubdomain: localWildcardSubdomain,
      wildcardFullHost: updatedWildcardFullHost,
      serverType: localServerType,
    })

    // Show saved indicator briefly
    showNotification("Settings saved successfully!")
  }

  // Handle wildcard checkbox change
  const handleUseWildcardChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const useWildcard = e.target.checked
    setLocalUseWildcard(useWildcard)

    // Update wildcard full host if using wildcard
    const updatedWildcardFullHost =
      useWildcard && localWildcardSubdomain ? `${localWildcardSubdomain}.${localHostName}` : localWildcardFullHost

    if (useWildcard && localWildcardSubdomain) {
      setLocalWildcardFullHost(updatedWildcardFullHost)
    }

    // Automatically save settings
    onSettingsChange({
      hostName: localHostName,
      useWildcard: useWildcard,
      wildcardSubdomain: localWildcardSubdomain,
      wildcardFullHost: updatedWildcardFullHost,
      serverType: localServerType,
    })

    // Show saved indicator briefly
    showNotification("Settings saved successfully!")
  }

  // Handle wildcard subdomain change
  const handleWildcardSubdomainChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const subdomain = e.target.value
    setLocalWildcardSubdomain(subdomain)
    const updatedWildcardFullHost = `${subdomain}.${localHostName}`
    setLocalWildcardFullHost(updatedWildcardFullHost)

    // Automatically save settings
    onSettingsChange({
      hostName: localHostName,
      useWildcard: localUseWildcard,
      wildcardSubdomain: subdomain,
      wildcardFullHost: updatedWildcardFullHost,
      serverType: localServerType,
    })

    // Show saved indicator briefly
    showNotification("Settings saved successfully!")
  }

  // Handle server type change
  const handleServerTypeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newServerType = e.target.value
    setLocalServerType(newServerType)

    // Automatically save settings
    onSettingsChange({
      hostName: localHostName,
      useWildcard: localUseWildcard,
      wildcardSubdomain: localWildcardSubdomain,
      wildcardFullHost: localWildcardFullHost,
      serverType: newServerType,
    })

    // Show saved indicator briefly
    showNotification("Settings saved successfully!")
  }

  // Update the handleSaveSettings function to include serverType
  const handleSaveSettings = () => {
    onSettingsChange({
      hostName: localHostName,
      useWildcard: localUseWildcard,
      wildcardSubdomain: localWildcardSubdomain,
      wildcardFullHost: localWildcardFullHost,
      serverType: localServerType,
    })

    showNotification("Settings saved successfully!")
  }

  // Add this function after the existing functions but before the return statement
  const checkProxyStatus = async () => {
    try {
      setCheckingStatus(true)

      // Use the same API as in the proxy list
      const response = await fetch(
        `/api/check-proxy?ip=${encodeURIComponent(proxy.proxyIP)}&port=${encodeURIComponent(proxy.proxyPort)}`,
      )

      if (!response.ok) {
        throw new Error(`API responded with status: ${response.status}`)
      }

      const data = await response.json()

      setProxyStatus({
        isActive: data.proxyip === true,
        latency: data.latency || "Unknown",
      })
    } catch (error) {
      console.error("Error checking proxy status:", error)
      setProxyStatus({
        isActive: false,
        latency: "Error",
      })
    } finally {
      setCheckingStatus(false)
    }
  }

  // Tambahkan log untuk memeriksa nilai yang diteruskan ke generateConfigs
  // Memoize configs to prevent recalculation on every render
  const configs = generateConfigs(
    localHostName,
    proxy,
    nameWEB,
    pathinfo,
    localUseWildcard,
    localWildcardSubdomain,
    localWildcardFullHost || `${localWildcardSubdomain}.${localHostName}`,
    {
      sslServers: availableSslServers && availableSslServers.length > 0 ? availableSslServers : ["inconigto.biz.id"], // Pastikan selalu ada default SSL server
      defaultServerType: localServerType || "WS",
      defaultHostname: localHostName,
    },
  )

  // Tambahkan log untuk memeriksa konfigurasi yang dihasilkan
  console.log("Generated configs with server type:", localServerType)
  console.log("Available SSL servers:", availableSslServers)
  console.log("Sample config (vlessTls):", configs.vlessTls)

  // Update the showNotification function with the same enhanced animation and design

  const showNotification = useCallback((message: string) => {
    // Remove any existing notifications first
    const existingNotifications = document.querySelectorAll(".copy-notification")
    existingNotifications.forEach((notification) => {
      document.body.removeChild(notification)
    })

    // Create the notification container
    const popup = document.createElement("div")
    popup.className = "copy-notification"
    popup.style.position = "fixed"
    popup.style.bottom = "30px"
    popup.style.left = "50%"
    popup.style.transform = "translateX(-50%) translateY(100px)"
    popup.style.backgroundColor = "rgba(0, 0, 0, 0.8)"
    popup.style.color = "#fff"
    popup.style.padding = "12px 20px"
    popup.style.borderRadius = "8px"
    popup.style.boxShadow = "0 4px 20px rgba(0, 0, 0, 0.3)"
    popup.style.zIndex = "9999"
    popup.style.transition = "all 0.5s cubic-bezier(0.68, -0.55, 0.27, 1.55)"
    popup.style.opacity = "0"
    popup.style.display = "flex"
    popup.style.alignItems = "center"
    popup.style.justifyContent = "center"
    popup.style.gap = "10px"
    popup.style.backdropFilter = "blur(5px)"
    popup.style.border = "1px solid rgba(255, 255, 255, 0.1)"
    popup.style.fontSize = "14px"
    popup.style.fontWeight = "500"

    // Add checkmark icon
    const icon = document.createElement("span")
    icon.innerHTML = `
      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M20 6L9 17l-5-5"></path>
      </svg>
    `
    icon.style.display = "flex"
    icon.style.alignItems = "center"
    icon.style.justifyContent = "center"
    icon.style.color = "#4ade80" // Green color for success
    icon.className = "checkmark-icon"

    // Add text
    const text = document.createElement("span")
    text.textContent = message

    // Append elements
    popup.appendChild(icon)
    popup.appendChild(text)
    document.body.appendChild(popup)

    // Animate in
    setTimeout(() => {
      popup.style.opacity = "1"
      popup.style.transform = "translateX(-50%) translateY(0)"
    }, 10)

    // Add pulse animation to the checkmark
    const keyframes = `
      @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.2); }
        100% { transform: scale(1); }
      }
    `
    const style = document.createElement("style")
    style.innerHTML = keyframes
    document.head.appendChild(style)

    icon.style.animation = "pulse 1s ease-in-out infinite"

    // Animate out after delay
    setTimeout(() => {
      popup.style.opacity = "0"
      popup.style.transform = "translateX(-50%) translateY(20px)"

      // Remove the element after animation completes
      setTimeout(() => {
        if (document.body.contains(popup)) {
          document.body.removeChild(popup)
        }
        if (document.head.contains(style)) {
          document.head.removeChild(style)
        }
      }, 500)
    }, 2000)
  }, [])

  // Add the basic settings UI before the configs section
  return (
    <Card className="bg-white/40 backdrop-blur-md text-tech-text border-none shadow-lg">
      {/* Header with proxy info */}
      <div className="p-3 sm:p-4 border-b border-white/30 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div className="flex items-center gap-3">
          <span className="text-3xl sm:text-4xl animate-float">{getEmojiFlag(country)}</span>
          <div>
            <h2 className="font-medium text-base sm:text-lg">{org}</h2>
            <p className="text-tech-muted text-xs sm:text-sm">{country}</p>
          </div>
        </div>
        {/* Replace the paragraph that displays the IP:PORT with this updated version */}
        <div className="text-right">
          <p className="text-tech-accent font-medium text-sm sm:text-base flex flex-col items-end">
            <span>
              {proxyIP}:{proxyPort}
            </span>
            {/* Also update the status display in the return statement to show a refresh button when status is already checked
            Replace the existing status display with this: */}
            {proxyStatus ? (
              <span className="flex items-center">
                <span className={`text-xs ${proxyStatus.isActive ? "text-tech-success" : "text-red-500"}`}>
                  {proxyStatus.isActive ? "ACTIVE" : "NON-ACTIVE"}
                  {proxyStatus.isActive && proxyStatus.latency !== "Error" && ` (${proxyStatus.latency})`}
                </span>
                <button
                  onClick={checkProxyStatus}
                  disabled={checkingStatus}
                  className="text-xs text-tech-muted hover:text-tech-accent transition-all duration-300 ml-2"
                  title="Refresh status"
                >
                  {checkingStatus ? "..." : "↻"}
                </button>
              </span>
            ) : (
              <span className="text-xs text-tech-muted animate-pulse">
                {checkingStatus ? "Checking status..." : "Status unknown"}
              </span>
            )}
          </p>
        </div>
      </div>

      {/* Basic Settings Section */}
      <div className="p-3 sm:p-4 border-b border-white/30 animate-fadeIn">
        <h3 className="text-base sm:text-lg font-medium text-tech-accent mb-3 text-center">Configuration Settings</h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4 mb-4">
          <div>
            <Label htmlFor="card-hostname" className="text-xs sm:text-sm mb-1 block">
              Base Hostname
            </Label>
            <select
              id="card-hostname"
              value={localHostName}
              onChange={handleHostNameChange}
              className="tech-select w-full text-xs sm:text-sm"
            >
              {availableHostNames.length > 0 ? (
                availableHostNames.map((host) => (
                  <option key={host} value={host}>
                    {host}
                  </option>
                ))
              ) : (
                <option value="">No hostnames available</option>
              )}
            </select>
          </div>

          <div>
            <div className="flex items-center mb-1">
              <input
                type="checkbox"
                id="card-use-wildcard"
                checked={localUseWildcard}
                onChange={handleUseWildcardChange}
                className="mr-2 h-3 w-3 sm:h-4 sm:w-4"
              />
              <Label htmlFor="card-use-wildcard" className="text-xs sm:text-sm">
                Use Bug Server
              </Label>
            </div>

            {localUseWildcard && (
              <select
                id="card-wildcard-subdomain"
                value={localWildcardSubdomain}
                onChange={handleWildcardSubdomainChange}
                className="tech-select w-full text-xs sm:text-sm"
                disabled={!localUseWildcard}
              >
                {availableBugServers.length > 0 ? (
                  availableBugServers.map((server) => (
                    <option key={server} value={server}>
                      {server}
                    </option>
                  ))
                ) : (
                  <option value="">No bug servers available</option>
                )}
              </select>
            )}
          </div>
        </div>

        {localUseWildcard && (
          <div className="mt-3">
            <Label htmlFor="server-type" className="text-xs sm:text-sm mb-1 block">
              Server Type
            </Label>
            <select
              id="server-type"
              value={localServerType}
              onChange={handleServerTypeChange}
              className="tech-select w-full text-xs sm:text-sm"
            >
              <option value="WS">WebSocket (WS)</option>
              <option value="SSL">SSL</option>
            </select>

            <div className="mt-2 text-xs text-tech-muted">
              {localServerType === "WS" ? (
                <span>
                  <span className="font-medium">WS Config:</span> Server: {localWildcardSubdomain} | SNI & Host:{" "}
                  {localWildcardFullHost || `${localWildcardSubdomain}.${localHostName}`}
                </span>
              ) : (
                <span>
                  <span className="font-medium">SSL Config:</span> Server:{" "}
                  {availableSslServers && availableSslServers.length > 0 ? availableSslServers[0] : localHostName} | SNI
                  & Host: {localWildcardFullHost || `${localWildcardSubdomain}.${localHostName}`}
                </span>
              )}
            </div>
          </div>
        )}

        <div className="flex justify-end">{/* Settings saved notification now shows as a popup */}</div>
      </div>

      {/* Simplified configuration tabs */}
      <div className="p-3 sm:p-4 space-y-4 sm:space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 sm:gap-6">
          {/* VLESS Section */}
          <div className="bg-white/30 backdrop-blur-md rounded-lg p-3 sm:p-4 shadow-sm">
            <h3 className="text-base sm:text-lg font-medium text-tech-accent mb-2 sm:mb-3 text-center">VLESS</h3>
            <div className="space-y-2 sm:space-y-3">
              <div>
                <p className="text-xs text-tech-muted mb-1">TLS Rotate</p>
                <div className="relative">
                  <pre className="tech-terminal text-xs p-2 max-h-16 sm:max-h-20 overflow-y-auto">
                    {configs.RTvlessTls}
                  </pre>
                  <CopyButton
                    value={configs.RTvlessTls}
                    className="absolute top-2 right-2 text-xs h-6 w-6 p-0"
                    onClick={() => showNotification("VLESS TLS Rotate copied!")}
                  >
                    Copy
                  </CopyButton>
                </div>
              </div>
              <div className="flex gap-2">
                <CopyButton
                  value={configs.vlessTls}
                  className="flex-1 text-xs h-7"
                  onClick={() => showNotification("VLESS TLS copied!")}
                >
                  TLS
                </CopyButton>
                <CopyButton
                  value={configs.vlessNTls}
                  className="flex-1 text-xs h-7"
                  onClick={() => showNotification("VLESS N-TLS copied!")}
                >
                  N-TLS
                </CopyButton>
              </div>
            </div>
          </div>

          {/* TROJAN Section */}
          <div className="bg-white/30 backdrop-blur-md rounded-lg p-3 sm:p-4 shadow-sm">
            <h3 className="text-base sm:text-lg font-medium text-tech-accent mb-2 sm:mb-3 text-center">TROJAN</h3>
            <div className="space-y-2 sm:space-y-3">
              <div>
                <p className="text-xs text-tech-muted mb-1">TLS Rotate</p>
                <div className="relative">
                  <pre className="tech-terminal text-xs p-2 max-h-16 sm:max-h-20 overflow-y-auto">
                    {configs.RTtrojanTls}
                  </pre>
                  <CopyButton
                    value={configs.RTtrojanTls}
                    className="absolute top-2 right-2 text-xs h-6 w-6 p-0"
                    onClick={() => showNotification("TROJAN TLS Rotate copied!")}
                  >
                    Copy
                  </CopyButton>
                </div>
              </div>
              <div className="flex gap-2">
                <CopyButton
                  value={configs.trojanTls}
                  className="flex-1 text-xs h-7"
                  onClick={() => showNotification("TROJAN TLS copied!")}
                >
                  TLS
                </CopyButton>
                <CopyButton
                  value={configs.trojanNTls}
                  className="flex-1 text-xs h-7"
                  onClick={() => showNotification("TROJAN N-TLS copied!")}
                >
                  N-TLS
                </CopyButton>
              </div>
            </div>
          </div>

          {/* SHADOWSOCKS Section */}
          <div className="bg-white/30 backdrop-blur-md rounded-lg p-3 sm:p-4 shadow-sm">
            <h3 className="text-base sm:text-lg font-medium text-tech-accent mb-2 sm:mb-3 text-center">SHADOWSOCKS</h3>
            <div className="space-y-2 sm:space-y-3">
              <div>
                <p className="text-xs text-tech-muted mb-1">TLS Rotate</p>
                <div className="relative">
                  <pre className="tech-terminal text-xs p-2 max-h-16 sm:max-h-20 overflow-y-auto">
                    {configs.RTssTls}
                  </pre>
                  <CopyButton
                    value={configs.RTssTls}
                    className="absolute top-2 right-2 text-xs h-6 w-6 p-0"
                    onClick={() => showNotification("SHADOWSOCKS TLS Rotate copied!")}
                  >
                    Copy
                  </CopyButton>
                </div>
              </div>
              <div className="flex gap-2">
                <CopyButton
                  value={configs.ssTls}
                  className="flex-1 text-xs h-7"
                  onClick={() => showNotification("SHADOWSOCKS TLS copied!")}
                >
                  TLS
                </CopyButton>
                <CopyButton
                  value={configs.ssNTls}
                  className="flex-1 text-xs h-7"
                  onClick={() => showNotification("SHADOWSOCKS N-TLS copied!")}
                >
                  N-TLS
                </CopyButton>
              </div>
            </div>
          </div>
        </div>

        {/* Clash Configs */}
        <div className="bg-white/30 backdrop-blur-md rounded-lg p-3 sm:p-4 shadow-sm">
          <h3 className="text-base sm:text-lg font-medium text-tech-accent mb-2 sm:mb-3 text-center">CLASH CONFIGS</h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 sm:gap-3">
            <CopyButton
              value={configs.clashVLTls}
              className="text-xs"
              onClick={() => showNotification("Clash VLESS copied!")}
            >
              Clash VLESS
            </CopyButton>
            <CopyButton
              value={configs.clashTRTls}
              className="text-xs"
              onClick={() => showNotification("Clash TROJAN copied!")}
            >
              Clash TROJAN
            </CopyButton>
            <CopyButton
              value={configs.clashSSTls}
              className="text-xs"
              onClick={() => showNotification("Clash SHADOWSOCKS copied!")}
            >
              Clash SHADOWSOCKS
            </CopyButton>
          </div>
        </div>

        {/* Copy All Button */}
        <div className="text-center pt-2">
          <CopyButton
            value={configs.allConfigs}
            className="tech-button text-sm px-4 sm:px-6 py-2 animate-pulse-soft"
            onClick={() => showNotification("All configurations copied!")}
          >
            Copy All Configurations
          </CopyButton>
        </div>
      </div>
    </Card>
  )
})

