"use client"

import React from "react"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { debugKVConnection } from "@/lib/settings-service"

export function DebugPanel() {
  const [debugInfo, setDebugInfo] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [showRawEnvVars, setShowRawEnvVars] = useState(false)

  const runDiagnostics = async () => {
    try {
      setLoading(true)
      setError(null)

      const result = await debugKVConnection()
      setDebugInfo(result)
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err))
    } finally {
      setLoading(false)
    }
  }

  const getStatusColor = (status: string) => {
    if (status === "working correctly") return "text-green-500"
    if (status === "not tested") return "text-yellow-500"
    return "text-red-500"
  }

  return (
    <Card className="p-4 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800">
      <h3 className="font-medium mb-2">Database Connection Diagnostics</h3>

      <div className="flex gap-2 mb-4">
        <Button onClick={runDiagnostics} disabled={loading} className="bg-yellow-500 hover:bg-yellow-600 text-white">
          {loading ? "Running Diagnostics..." : "Run Diagnostics"}
        </Button>

        {debugInfo && (
          <Button
            onClick={() => setShowRawEnvVars(!showRawEnvVars)}
            className="bg-gray-500 hover:bg-gray-600 text-white"
          >
            {showRawEnvVars ? "Hide Raw Data" : "Show Raw Data"}
          </Button>
        )}
      </div>

      {error && (
        <div className="p-2 bg-red-100 dark:bg-red-900/20 text-red-800 dark:text-red-200 rounded mb-4">{error}</div>
      )}

      {debugInfo && !showRawEnvVars && (
        <div className="space-y-4">
          <div className="p-3 bg-white dark:bg-gray-800 rounded shadow-sm">
            <h4 className="font-medium mb-2">KV Connection Status</h4>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div className="font-medium">Status:</div>
              <div className={getStatusColor(debugInfo.kvStatus)}>{debugInfo.kvStatus}</div>

              {debugInfo.kvError && (
                <>
                  <div className="font-medium">Error:</div>
                  <div className="text-red-500">{debugInfo.kvError}</div>
                </>
              )}

              <div className="font-medium">Configuration Valid:</div>
              <div className={debugInfo.kvDetails?.isValid ? "text-green-500" : "text-red-500"}>
                {debugInfo.kvDetails?.isValid ? "Yes" : "No"}
              </div>
            </div>
          </div>

          <div className="p-3 bg-white dark:bg-gray-800 rounded shadow-sm">
            <h4 className="font-medium mb-2">Environment Variables</h4>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div className="font-medium">KV_REST_API_URL:</div>
              <div>{debugInfo.environmentVariables?.KV_REST_API_URL || "not set"}</div>

              <div className="font-medium">Normalized URL:</div>
              <div>{debugInfo.environmentVariables?.KV_REST_API_URL_NORMALIZED || "not set"}</div>

              <div className="font-medium">KV_REST_API_TOKEN:</div>
              <div>{debugInfo.environmentVariables?.KV_REST_API_TOKEN || "not set"}</div>

              <div className="font-medium">Token Length:</div>
              <div>{debugInfo.environmentVariables?.KV_REST_API_TOKEN_LENGTH || "0"}</div>

              <div className="font-medium">Environment:</div>
              <div>{debugInfo.environment || "unknown"}</div>
            </div>
          </div>

          {debugInfo.redisUrlFound && (
            <div className="p-3 bg-white dark:bg-gray-800 rounded shadow-sm border-l-4 border-yellow-500">
              <h4 className="font-medium mb-2">Redis URL Found!</h4>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="font-medium">Found in:</div>
                <div>{debugInfo.redisUrlInfo?.key}</div>

                <div className="font-medium">URL:</div>
                <div>{debugInfo.redisUrlInfo?.url}</div>
              </div>
              <p className="mt-2 text-sm text-yellow-600 dark:text-yellow-400">
                This might be the correct URL to use, but it needs to be converted to an HTTPS URL.
              </p>
            </div>
          )}

          {debugInfo.redisUrlParseInfo && (
            <div className="p-3 bg-white dark:bg-gray-800 rounded shadow-sm">
              <h4 className="font-medium mb-2">Redis URL Information</h4>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="font-medium">Protocol:</div>
                <div>{debugInfo.redisUrlParseInfo.protocol}</div>

                <div className="font-medium">Hostname:</div>
                <div>{debugInfo.redisUrlParseInfo.hostname}</div>

                <div className="font-medium">Port:</div>
                <div>{debugInfo.redisUrlParseInfo.port}</div>

                <div className="font-medium">Normalized URL:</div>
                <div>{debugInfo.redisUrlParseInfo.normalizedUrl}</div>
              </div>
            </div>
          )}

          {Object.keys(debugInfo.additionalKVVariables || {}).length > 0 && (
            <div className="p-3 bg-white dark:bg-gray-800 rounded shadow-sm">
              <h4 className="font-medium mb-2">Additional KV Variables</h4>
              <div className="grid grid-cols-2 gap-2 text-sm">
                {Object.entries(debugInfo.additionalKVVariables).map(([key, value]) => (
                  <React.Fragment key={key}>
                    <div className="font-medium">{key}:</div>
                    <div>{value}</div>
                  </React.Fragment>
                ))}
              </div>
            </div>
          )}

          <div className="p-3 bg-white dark:bg-gray-800 rounded shadow-sm border-l-4 border-blue-500">
            <h4 className="font-medium mb-2">Recommendations</h4>
            <ul className="list-disc pl-5 text-sm space-y-1">
              {debugInfo.recommendations?.map((recommendation, index) => (
                <li key={index} className="text-blue-600 dark:text-blue-400">
                  {recommendation}
                </li>
              ))}

              {!debugInfo.recommendations?.length && (
                <li className="text-gray-500">No specific recommendations available. Run diagnostics first.</li>
              )}
            </ul>
          </div>

          {debugInfo.kvDetails?.error && (
            <div className="p-3 bg-white dark:bg-gray-800 rounded shadow-sm border-l-4 border-red-500">
              <h4 className="font-medium mb-2">Error Details</h4>
              <p className="text-red-500 text-sm">{debugInfo.kvDetails.error}</p>
            </div>
          )}
        </div>
      )}

      {debugInfo && showRawEnvVars && (
        <div className="text-xs overflow-auto max-h-96 p-2 bg-gray-100 dark:bg-gray-800 rounded">
          <pre>{JSON.stringify(debugInfo, null, 2)}</pre>
        </div>
      )}

      <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-900/20 rounded border border-blue-200 dark:border-blue-800">
        <h4 className="font-medium mb-2 text-blue-700 dark:text-blue-300">Cara Memperbaiki Masalah</h4>
        <p className="text-sm text-gray-700 dark:text-gray-300 mb-2">
          Berdasarkan error yang Anda dapatkan, URL Upstash KV Anda tidak valid. URL yang diterima adalah
          "ep4itN0flglq6MYMDvCztJgp", yang bukan URL HTTP yang valid.
        </p>
        <ol className="list-decimal pl-5 text-sm space-y-1 text-gray-700 dark:text-gray-300">
          <li>Buka dashboard Vercel dan cari integrasi Upstash KV Anda</li>
          <li>Periksa variabel lingkungan yang dibuat oleh integrasi</li>
          <li>
            Pastikan <code className="bg-gray-200 dark:bg-gray-700 px-1 rounded">KV_REST_API_URL</code> berisi URL
            lengkap yang dimulai dengan <code className="bg-gray-200 dark:bg-gray-700 px-1 rounded">https://</code>
          </li>
          <li>
            Jika Anda melihat variabel lingkungan lain yang berisi URL Upstash yang valid (seperti{" "}
            <code className="bg-gray-200 dark:bg-gray-700 px-1 rounded">KV_REST_API_URL_KV_REST_API_URL</code>), gunakan
            nilai tersebut
          </li>
          <li>
            Perbarui variabel lingkungan{" "}
            <code className="bg-gray-200 dark:bg-gray-700 px-1 rounded">KV_REST_API_URL</code> dengan URL yang benar
          </li>
        </ol>
      </div>
    </Card>
  )
}

