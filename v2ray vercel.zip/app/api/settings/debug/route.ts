import { NextResponse } from "next/server"
import { getKVConnectionDetails, normalizeKVUrl, findRedisUrlInEnv } from "@/lib/kv-helper"

export async function GET() {
  try {
    // Get KV connection details
    const kvDetails = getKVConnectionDetails()
    const redisUrlInfo = findRedisUrlInEnv()

    // Check environment variables
    const envVars = {
      KV_REST_API_URL: process.env.KV_REST_API_URL ? `${process.env.KV_REST_API_URL.substring(0, 30)}...` : "not set",
      KV_REST_API_URL_NORMALIZED: kvDetails.normalizedUrl
        ? `${kvDetails.normalizedUrl.substring(0, 30)}...`
        : "not set",
      KV_REST_API_TOKEN: process.env.KV_REST_API_TOKEN
        ? `${process.env.KV_REST_API_TOKEN.substring(0, 5)}...`
        : "not set",
      KV_REST_API_TOKEN_LENGTH: process.env.KV_REST_API_TOKEN?.length || 0,
      NODE_ENV: process.env.NODE_ENV,
    }

    // Check for additional environment variables that might be causing confusion
    const additionalVars = {}
    for (const key in process.env) {
      if (key.includes("KV_") || key.includes("UPSTASH_") || key.includes("REDIS_")) {
        additionalVars[key] = `${process.env[key]?.substring(0, 10)}...`
      }
    }

    let kvStatus = "not tested"
    let kvError = null
    let testResults = null

    // Test KV connection if environment variables are present
    if (kvDetails.isValid) {
      try {
        const { kv } = await import("@vercel/kv")

        // Test connection with ping
        const pingResult = await kv.ping()

        // Try to set and get a test value
        const testKey = `test_key_${Date.now()}`
        const testValue = `test_value_${Date.now()}`

        await kv.set(testKey, testValue)
        const retrievedValue = await kv.get(testKey)

        // Clean up test key
        await kv.del(testKey)

        kvStatus =
          retrievedValue === testValue
            ? "working correctly"
            : `value mismatch: expected "${testValue}", got "${retrievedValue}"`

        testResults = {
          pingResult,
          testKey,
          testValue,
          retrievedValue,
          match: retrievedValue === testValue,
        }
      } catch (error) {
        kvStatus = "connection failed"
        kvError = error instanceof Error ? error.message : String(error)
      }
    } else {
      kvStatus = "invalid configuration"
    }

    // Try to parse Redis URL if present
    let redisUrlParseInfo = null
    if (
      process.env.KV_REST_API_URL &&
      (process.env.KV_REST_API_URL.startsWith("redis://") || process.env.KV_REST_API_URL.startsWith("rediss://"))
    ) {
      try {
        const url = process.env.KV_REST_API_URL
        const match = url.match(/redis(s?):\/\/(.*?):(.*?)@([^:]+):(\d+)/)
        if (match) {
          redisUrlParseInfo = {
            protocol: match[1] ? "rediss" : "redis",
            username: match[2],
            password: `${match[3].substring(0, 5)}...`,
            hostname: match[4],
            port: match[5],
            normalizedUrl: normalizeKVUrl(url),
          }
        }
      } catch (e) {
        redisUrlParseInfo = { error: String(e) }
      }
    }

    // Recommendations based on findings
    const recommendations = []

    if (!kvDetails.isValid) {
      recommendations.push(
        "Your KV_REST_API_URL is not valid. It should be a full HTTPS URL like https://your-database.upstash.io",
      )
    }

    if (kvDetails.url && /^[a-zA-Z0-9]+$/.test(kvDetails.url)) {
      recommendations.push(
        "Your KV_REST_API_URL appears to be just a token or ID, not a valid URL. Check your environment variables.",
      )
    }

    if (redisUrlInfo.found) {
      recommendations.push(
        `Found a Redis URL in ${redisUrlInfo.key}. You might want to use this as your KV_REST_API_URL instead, but convert it to an HTTPS URL.`,
      )
    }

    if (kvError && kvError.includes("invalid URL")) {
      recommendations.push(
        "The URL format is invalid. Make sure it starts with https:// and is a valid Upstash endpoint.",
      )
    }

    return NextResponse.json({
      success: true,
      timestamp: new Date().toISOString(),
      environment: process.env.NODE_ENV,
      environmentVariables: envVars,
      additionalKVVariables: additionalVars,
      kvStatus,
      kvError,
      testResults,
      redisUrlParseInfo,
      redisUrlFound: redisUrlInfo.found,
      redisUrlInfo: redisUrlInfo.found
        ? {
            key: redisUrlInfo.key,
            url: `${redisUrlInfo.url?.substring(0, 20)}...`,
          }
        : null,
      kvDetails: {
        originalUrl: kvDetails.url ? `${kvDetails.url.substring(0, 30)}...` : "not set",
        normalizedUrl: kvDetails.normalizedUrl ? `${kvDetails.normalizedUrl.substring(0, 30)}...` : "not set",
        hasToken: !!kvDetails.token,
        tokenLength: kvDetails.token?.length || 0,
        isValid: kvDetails.isValid,
        error: kvDetails.error,
      },
      recommendations,
    })
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : String(error),
      },
      { status: 500 },
    )
  }
}

