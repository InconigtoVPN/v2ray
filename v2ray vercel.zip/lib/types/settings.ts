export interface AdminSettings {
  hostnames: string[]
  bugServers: string[]
  defaultHostname: string
  defaultPathInfo: string
  defaultNameWEB: string
  defaultTelegram: string
  defaultServerType: string
  sslServers: string[]
  ownerPin?: string
  lastUpdated: string
}

export interface SettingsResponse {
  success: boolean
  data?: AdminSettings
  error?: string
}

