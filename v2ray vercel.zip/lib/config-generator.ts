import type { Proxy } from "@/types/proxy"
import { getEmojiFlag } from "./utils"

// Cache for generated UUIDs to improve performance\
const uuidCache: Record<string, string> = {}

// Ubah fungsi getServerConfig untuk menyederhanakan logika SSL server
function getServerConfig(
  bugServer: string,
  sslServers: string[],
  hostname: string,
  serverType: string,
): { server: string; sniHost: string } {
  // Check if we're using a bug server (wildcard) or not
  const isUsingBugServer = bugServer !== hostname

  if (serverType === "SSL") {
    // For SSL configuration:
    // Server should be the hostname (not the SSL server)
    // SNI & Host should be bugserver.hostname
    const server = hostname
    const sniHost = isUsingBugServer ? `${bugServer}.${hostname}` : hostname

    console.log(`Using SSL configuration: server=${server}, sniHost=${sniHost}`)

    return {
      server: server,
      sniHost: sniHost,
    }
  } else {
    // For WS configuration:
    // Server should be bugserver
    // SNI & Host should be bugserver.hostname
    const server = isUsingBugServer ? bugServer : hostname
    const sniHost = isUsingBugServer ? `${bugServer}.${hostname}` : hostname

    console.log(`Using WS configuration: server=${server}, sniHost=${sniHost}`)

    return {
      server: server,
      sniHost: sniHost,
    }
  }
}

// Ubah fungsi generateConfigs untuk menangani kasus di mana settings mungkin undefined
export function generateConfigs(
  hostName: string,
  proxy: Proxy,
  nameWEB: string,
  pathinfo: string,
  useWildcard = false,
  wildcardSubdomain = "",
  wildcardFullHost = "",
  settings?: any, // Tambahkan parameter settings dengan tipe any dan opsional
) {
  const { proxyIP, proxyPort, country, org } = proxy

  const bugServer = useWildcard ? wildcardSubdomain : hostName

  // Tentukan nilai default untuk settings jika tidak disediakan
  const defaultSettings = {
    sslServers: ["inconigto.biz.id"], // Default SSL server
    defaultServerType: "WS",
    defaultHostname: hostName,
  }

  // Gunakan settings yang disediakan atau default jika tidak ada
  const configSettings = settings || defaultSettings

  // Log untuk debugging
  console.log("generateConfigs settings:", {
    sslServers: configSettings.sslServers,
    serverType: configSettings.defaultServerType,
    hostname: configSettings.defaultHostname,
  })

  // Determine the actual server, sni and host values based on wildcard settings
  const wsHost = useWildcard ? wildcardFullHost : hostName

  const { server: serverHost, sniHost } = getServerConfig(
    bugServer,
    configSettings.sslServers || defaultSettings.sslServers,
    configSettings.defaultHostname || hostName,
    configSettings.defaultServerType || "WS",
  )

  // Log hasil konfigurasi
  console.log("Final configuration:", { serverHost, sniHost, wsHost })

  // Helper functions
  const encodePath = (pathinfo: string, proxyIP: string, proxyPort: string) => {
    const cleanedProxyIP = proxyIP.trim()
    return `%2F${encodeURIComponent(pathinfo)}%2F${encodeURIComponent(cleanedProxyIP)}%2F${encodeURIComponent(proxyPort)}`
  }

  const encodePathRT = (pathinfo: string, country: string) => {
    return `%2F${encodeURIComponent(pathinfo)}%2F${encodeURIComponent(country)}`
  }

  const encodeSpace = (string: string) => {
    return encodeURIComponent(string).replace(/\s+/g, "")
  }

  // Generate paths
  const pathcode = encodePath(pathinfo, proxyIP, proxyPort)
  const ispcode = `${getEmojiFlag(country)} (${country}) ${org}`
  const encodeIsp = encodeSpace(ispcode)
  const clashpath = `/${pathinfo}/${proxyIP}/${proxyPort}`

  const RTpath = encodePathRT(pathinfo, country)
  const RTname = `${getEmojiFlag(country)} (${country})`

  // Generate UUIDs - use cached values if available for better performance
  const generateUUID = () => {
    const cacheKey = `${proxyIP}:${proxyPort}`
    if (!uuidCache[cacheKey]) {
      uuidCache[cacheKey] = crypto.randomUUID()
    }
    return uuidCache[cacheKey]
  }

  const encode = encodeSpace(nameWEB)

  // Generate config strings
  const vlessTls = `vless://${generateUUID()}@${serverHost}:443?encryption=none&security=tls&sni=${sniHost}&fp=randomized&type=ws&host=${sniHost}&path=${pathcode}#${encode}-[Tls]-[VL]-[${nameWEB}]`
  const vlessNTls = `vless://${generateUUID()}@${serverHost}:80?encryption=none&security=none&sni=${sniHost}&fp=randomized&type=ws&host=${sniHost}&path=${pathcode}#${encode}-[NTls]-[VL]-[${nameWEB}]`

  const trojanTls = `trojan://${generateUUID()}@${serverHost}:443?encryption=none&security=tls&sni=${sniHost}&fp=randomized&type=ws&host=${sniHost}&path=${pathcode}#${encode}-[Tls]-[TR]-[${nameWEB}]`
  const trojanNTls = `trojan://${generateUUID()}@${serverHost}:80?encryption=none&security=none&sni=${sniHost}&fp=randomized&type=ws&host=${sniHost}&path=${pathcode}#${encode}-[NTls]-[TR]-[${nameWEB}]`

  const ssTls = `ss://${btoa(`none:${generateUUID()}`)}@${serverHost}:443?encryption=none&type=ws&host=${sniHost}&path=${pathcode}&security=tls&sni=${sniHost}#${encode}-[Tls]-[SS]-[${nameWEB}]`
  const ssNTls = `ss://${btoa(`none:${generateUUID()}`)}@${serverHost}:80?encryption=none&type=ws&host=${sniHost}&path=${pathcode}&security=none&sni=${sniHost}#${encodeIsp}-[NTls]-[SS]-[${nameWEB}]`

  // Rotate configs
  const RTvlessTls = `vless://${generateUUID()}@${serverHost}:443?encryption=none&security=tls&sni=${sniHost}&fp=randomized&type=ws&host=${sniHost}&path=${RTpath}#${RTname}-[Tls]-[VL]-[${nameWEB}]`
  const RTtrojanTls = `trojan://${generateUUID()}@${serverHost}:443?encryption=none&security=tls&sni=${sniHost}&fp=randomized&type=ws&host=${sniHost}&path=${RTpath}#${RTname}-[Tls]-[TR]-[${nameWEB}]`
  const RTssTls = `ss://${btoa(`none:${generateUUID()}`)}@${serverHost}:443?encryption=none&type=ws&host=${sniHost}&path=${RTpath}&security=tls&sni=${sniHost}#${RTname}-[Tls]-[SS]-[${nameWEB}]`

  // Clash configs
  const vlname = `${getEmojiFlag(country)} (${country}) ${org}-[Tls]-[VL]-[${nameWEB}]`
  const trname = `${getEmojiFlag(country)} (${country}) ${org}-[Tls]-[TR]-[${nameWEB}]`
  const ssname = `${getEmojiFlag(country)} (${country}) ${org}-[Tls]-[SS]-[${nameWEB}]`

  const clashVLTls = `
#InconigtoVPN
proxies:
- name: ${vlname}
  server: ${serverHost}
  port: 443
  type: vless
  uuid: ${generateUUID()}
  cipher: auto
  tls: true
  client-fingerprint: chrome
  udp: false
  skip-cert-verify: true
  network: ws
  servername: ${sniHost}
  alpn:
    - h2
    - h3
    - http/1.1
  ws-opts:
    path: ${clashpath}
    headers:
      Host: ${sniHost}
    max-early-data: 0
    early-data-header-name: Sec-WebSocket-Protocol
    ip-version: dual
    v2ray-http-upgrade: false
    v2ray-http-upgrade-fast-open: false
`

  const clashTRTls = `
#InconigtoVPN
proxies:      
- name: ${trname}
  server: ${serverHost}
  port: 443
  type: trojan
  password: ${generateUUID()}
  tls: true
  client-fingerprint: chrome
  udp: false
  skip-cert-verify: true
  network: ws
  sni: ${sniHost}
  alpn:
    - h2
    - h3
    - http/1.1
  ws-opts:
    path: ${clashpath}
    headers:
      Host: ${sniHost}
    max-early-data: 0
    early-data-header-name: Sec-WebSocket-Protocol
    ip-version: dual
    v2ray-http-upgrade: false
    v2ray-http-upgrade-fast-open: false
`

  const clashSSTls = `
#InconigtoVPN
proxies:
- name: ${ssname}
  server: ${serverHost}
  port: 443
  type: ss
  cipher: none
  password: ${generateUUID()}
  plugin: v2ray-plugin
  client-fingerprint: chrome
  udp: false
  plugin-opts:
    mode: websocket
    host: ${sniHost}
    path: ${clashpath}
    tls: true
    mux: false
    skip-cert-verify: true
  headers:
    custom: value
    ip-version: dual
    v2ray-http-upgrade: false
    v2ray-http-upgrade-fast-open: false
`

  // Combine all configs
  const allConfigs = [ssTls, ssNTls, vlessTls, vlessNTls, trojanTls, trojanNTls, RTvlessTls, RTtrojanTls, RTssTls].join(
    "\n\n",
  )

  return {
    vlessTls,
    vlessNTls,
    trojanTls,
    trojanNTls,
    ssTls,
    ssNTls,
    RTvlessTls,
    RTtrojanTls,
    RTssTls,
    clashVLTls,
    clashTRTls,
    clashSSTls,
    allConfigs,
  }
}

